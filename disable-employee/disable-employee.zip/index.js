const AWS = require("aws-sdk");
const s3 = new AWS.S3();

exports.handler = async (event, context) => {
  const body = JSON.parse(event.body);
  const id = body.id;

  await s3.deleteObject({
    Bucket: "active-employee-files",
    Key: id,
  }).promise();

  await s3.upload({
    Bucket: "inactive-employee-files",
    Key: id,
    Body: await s3.getObject({
      Bucket: "active-employee-files",
      Key: id,
    }).promise().Body,
  }).promise();

  return {
    statusCode: 200,
    body: "El archivo se ha eliminado y pasado correctamente",
  };
};